# تعليمات نشر المشروع على GitHub

## الخطوة 1: إنشاء مستودع على GitHub

1. اذهب إلى [GitHub](https://github.com)
2. اضغط على **New Repository** (مستودع جديد)
3. أدخل اسم المستودع: `sonatrach_club`
4. أضف وصف: "موقع نادي سونطراك الرياضي والثقافي"
5. اختر **Public** (عام) أو **Private** (خاص)
6. اضغط **Create Repository**

## الخطوة 2: إعداد Git محلياً

```bash
# انتقل إلى مجلد المشروع
cd sonatrach_club

# تهيئة git (إذا لم يكن مهيأ)
git init

# أضف جميع الملفات
git add .

# أنشئ أول commit
git commit -m "Initial commit: Sonatrach Club website with login page"

# أضف remote repository (استبدل USERNAME و REPO_NAME)
git remote add origin https://github.com/USERNAME/sonatrach_club.git

# أرسل الملفات إلى GitHub
git branch -M main
git push -u origin main
```

## الخطوة 3: إعدادات GitHub المهمة

### تفعيل GitHub Pages (اختياري - لاستضافة الموقع مجاناً)

1. اذهب إلى **Settings** في مستودعك
2. اختر **Pages** من الجانب الأيسر
3. تحت **Source**، اختر **GitHub Actions**
4. سيتم بناء ونشر الموقع تلقائياً

### إضافة ملف Workflow للبناء التلقائي

أنشئ ملف `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [18.x]

    steps:
    - uses: actions/checkout@v3
    
    - name: Use Node.js ${{ matrix.node-version }}
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}
    
    - name: Install pnpm
      run: npm install -g pnpm
    
    - name: Install dependencies
      run: pnpm install
    
    - name: Build
      run: pnpm build
    
    - name: Deploy to GitHub Pages
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

## الخطوة 4: التحديثات المستقبلية

لإرسال تحديثات جديدة:

```bash
# أضف التغييرات
git add .

# أنشئ commit
git commit -m "وصف التغييرات"

# أرسل التحديثات
git push origin main
```

## الخطوة 5: إضافة README.md

تأكد من وجود ملف `README.md` في جذر المشروع يحتوي على:
- وصف المشروع
- كيفية التثبيت
- كيفية التشغيل
- الميزات الرئيسية
- المكدس التقني

## الخطوة 6: إضافة ملف LICENSE

أضف ملف `LICENSE` (اختياري لكن موصى به):

```bash
# للرخصة MIT
echo "MIT License" > LICENSE
```

## الخطوة 7: إضافة .gitignore

تأكد من وجود ملف `.gitignore` يحتوي على:
- `node_modules/`
- `.env`
- `dist/`
- `.vite/`

## الخطوة 8: إضافة Contributors

1. اذهب إلى **Settings**
2. اختر **Manage access**
3. أضف المساهمين

## نصائح مهمة

### للعمل التعاوني:

```bash
# إنشاء branch جديد للميزات
git checkout -b feature/new-feature

# بعد الانتهاء، أرسل Pull Request
git push origin feature/new-feature
```

### للحفاظ على المستودع محدثاً:

```bash
# سحب آخر التحديثات
git pull origin main

# دمج التحديثات المحلية
git merge origin/main
```

## استكشاف الأخطاء

### خطأ: "fatal: not a git repository"
```bash
git init
```

### خطأ: "Permission denied"
تأكد من إضافة مفتاح SSH أو استخدام Personal Access Token

### خطأ: "branch 'main' set up to track 'origin/main'"
```bash
git branch -u origin/main main
```

## الروابط المفيدة

- [GitHub Documentation](https://docs.github.com)
- [Git Cheat Sheet](https://github.github.com/training-kit/downloads/github-git-cheat-sheet.pdf)
- [GitHub Pages](https://pages.github.com)

---

**تم إعداد المشروع بنجاح! الآن يمكنك نشره على GitHub بسهولة.**
