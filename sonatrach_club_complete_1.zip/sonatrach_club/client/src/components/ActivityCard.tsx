import { Button } from '@/components/ui/button';
import { LucideIcon } from 'lucide-react';

interface ActivityCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  onRegister: () => void;
}

export default function ActivityCard({ icon: Icon, title, description, onRegister }: ActivityCardProps) {
  return (
    <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden hover:-translate-y-2">
      <div className="p-8 text-center">
        <div className="flex justify-center mb-4">
          <div className="p-4 bg-gradient-to-br from-[#003087]/10 to-[#e30613]/10 rounded-full">
            <Icon size={48} className="text-[#003087]" />
          </div>
        </div>
        <h3 className="text-xl font-bold text-[#003087] mb-3">{title}</h3>
        <p className="text-gray-600 mb-6 text-sm leading-relaxed">{description}</p>
        <Button 
          onClick={onRegister}
          className="w-full bg-gradient-to-r from-[#003087] to-[#00205b] hover:from-[#e30613] hover:to-[#b80410] text-white font-semibold py-2 rounded-lg transition-all duration-300"
        >
          تسجيل الآن
        </Button>
      </div>
    </div>
  );
}
