import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import RegistrationForm from './RegistrationForm';

interface RegistrationDialogProps {
  open: boolean;
  activity: string;
  onOpenChange: (open: boolean) => void;
}

export default function RegistrationDialog({ open, activity, onOpenChange }: RegistrationDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">نموذج التسجيل في النشاط</DialogTitle>
        </DialogHeader>
        <RegistrationForm activity={activity} onClose={() => onOpenChange(false)} />
      </DialogContent>
    </Dialog>
  );
}
