import { useLocation } from 'wouter';
import { LogOut } from 'lucide-react';
import { toast } from 'sonner';

export default function LogoutButton() {
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    localStorage.removeItem('user');
    toast.success('تم تسجيل الخروج بنجاح');
    setLocation('/login');
  };

  return (
    <button
      onClick={handleLogout}
      className="flex items-center gap-2 px-4 py-2 text-white hover:bg-white/10 rounded-lg transition-colors duration-300"
      title="تسجيل الخروج"
    >
      <LogOut size={20} />
      <span className="hidden sm:inline text-sm">خروج</span>
    </button>
  );
}
