import { useState } from 'react';
import { Search, Play } from 'lucide-react';

interface GalleryItemProps {
  src: string;
  alt: string;
  isVideo?: boolean;
}

export default function GalleryItem({ src, alt, isVideo = false }: GalleryItemProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="relative overflow-hidden rounded-xl shadow-lg cursor-pointer group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {isVideo ? (
        <video
          src={src}
          className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
          poster="https://via.placeholder.com/400x300/6f42c1/ffffff?text=فيديو"
        />
      ) : (
        <img
          src={src}
          alt={alt}
          className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
        />
      )}

      {/* الطبقة العلوية عند التمرير */}
      <div
        className={`absolute inset-0 bg-gradient-to-b from-[#003087]/70 to-[#003087]/50 flex items-center justify-center transition-opacity duration-300 ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}
      >
        {isVideo ? (
          <Play size={48} className="text-white fill-white" />
        ) : (
          <Search size={48} className="text-white" />
        )}
      </div>
    </div>
  );
}
