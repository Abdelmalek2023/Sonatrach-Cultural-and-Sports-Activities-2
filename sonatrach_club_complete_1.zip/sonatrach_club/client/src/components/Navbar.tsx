import { useState, useEffect } from 'react';
import { Menu, X, ChevronUp, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { toast } from 'sonner';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [, setLocation] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);

      // تحديث القسم النشط بناءً على موضع التمرير
      const sections = ['home', 'activities', 'news', 'gallery', 'register', 'contact'];
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
      setIsOpen(false);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    toast.success('تم تسجيل الخروج بنجاح');
    setLocation('/login');
  };

  const navItems = [
    { id: 'home', label: 'الرئيسية' },
    { id: 'activities', label: 'الأنشطة' },
    { id: 'news', label: 'الأخبار' },
    { id: 'gallery', label: 'المعرض' },
    { id: 'register', label: 'التسجيل' },
    { id: 'contact', label: 'اتصل بنا' },
  ];

  return (
    <>
      <nav className="fixed top-0 right-0 left-0 z-50 bg-gradient-to-l from-[#003087] to-[#00205b] shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            {/* الشعار */}
            <a href="#home" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/e/ef/Sonatrach.svg" 
                alt="شعار سونطراك" 
                className="h-14 w-auto"
              />
            </a>

            {/* قائمة التنقل للشاشات الكبيرة */}
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`px-4 py-2 rounded-lg transition-all duration-300 font-medium ${
                    activeSection === item.id
                      ? 'bg-white text-[#003087]'
                      : 'text-white hover:bg-white/10'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <div className="border-r border-white/20 mx-2 h-6"></div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2 text-white hover:bg-white/10 rounded-lg transition-colors duration-300"
                title="تسجيل الخروج"
              >
                <LogOut size={20} />
                <span className="text-sm">خروج</span>
              </button>
            </div>

            {/* زر القائمة للأجهزة الصغيرة */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden text-white p-2 hover:bg-white/10 rounded-lg transition-colors"
              aria-label="تبديل القائمة"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* القائمة المنسدلة للأجهزة الصغيرة */}
          {isOpen && (
            <div className="md:hidden pb-4 space-y-2 animate-in fade-in slide-in-from-top-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`w-full text-right px-4 py-3 rounded-lg transition-all duration-300 font-medium ${
                    activeSection === item.id
                      ? 'bg-white text-[#003087]'
                      : 'text-white hover:bg-white/10'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <div className="border-t border-white/20 my-2"></div>
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-end gap-2 px-4 py-3 text-white hover:bg-white/10 rounded-lg transition-colors duration-300 font-medium"
              >
                <span>خروج</span>
                <LogOut size={20} />
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* زر العودة للأعلى */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-8 left-8 z-40 bg-[#e30613] text-white p-3 rounded-full shadow-lg hover:bg-[#003087] transition-all duration-300 animate-in fade-in slide-in-from-bottom-4"
          aria-label="العودة للأعلى"
        >
          <ChevronUp size={24} />
        </button>
      )}
    </>
  );
}
