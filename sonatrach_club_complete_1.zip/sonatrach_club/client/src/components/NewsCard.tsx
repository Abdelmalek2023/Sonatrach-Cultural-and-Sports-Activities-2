interface NewsCardProps {
  image: string;
  category: string;
  categoryColor: string;
  title: string;
  date: string;
  description: string;
}

export default function NewsCard({ image, category, categoryColor, title, date, description }: NewsCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden hover:-translate-y-1">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      <div className="p-5">
        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold text-white mb-3 ${categoryColor}`}>
          {category}
        </span>
        <h3 className="text-lg font-bold text-[#003087] mb-2 line-clamp-2">{title}</h3>
        <p className="text-gray-500 text-xs mb-3">{date}</p>
        <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">{description}</p>
      </div>
    </div>
  );
}
