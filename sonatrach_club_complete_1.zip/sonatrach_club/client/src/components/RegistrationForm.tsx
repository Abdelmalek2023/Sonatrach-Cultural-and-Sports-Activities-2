import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface RegistrationFormProps {
  activity: string;
  onClose: () => void;
}

export default function RegistrationForm({ activity, onClose }: RegistrationFormProps) {
  const [formData, setFormData] = useState({
    fullName: '',
    age: '',
    phone: '',
    email: '',
    level: 'مبتدئ',
    notes: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // التحقق من البيانات
    if (!formData.fullName.trim()) {
      toast.error('الرجاء إدخال الاسم الكامل');
      return;
    }

    if (!formData.age || parseInt(formData.age) < 5 || parseInt(formData.age) > 70) {
      toast.error('الرجاء إدخال عمر صحيح (بين 5 و 70 سنة)');
      return;
    }

    if (!formData.phone.trim()) {
      toast.error('الرجاء إدخال رقم الهاتف');
      return;
    }

    if (!formData.email.includes('@')) {
      toast.error('الرجاء إدخال بريد إلكتروني صحيح');
      return;
    }

    setIsSubmitting(true);

    // محاكاة إرسال البيانات
    setTimeout(() => {
      toast.success(`تم التسجيل بنجاح في نشاط ${activity}! سيتم التواصل معك قريباً.`);
      setFormData({
        fullName: '',
        age: '',
        phone: '',
        email: '',
        level: 'مبتدئ',
        notes: '',
      });
      setIsSubmitting(false);
      onClose();
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">الاسم الكامل</label>
          <input
            type="text"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition"
            placeholder="أدخل اسمك الكامل"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">العمر</label>
          <input
            type="number"
            name="age"
            value={formData.age}
            onChange={handleChange}
            min="5"
            max="70"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition"
            placeholder="أدخل عمرك"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition"
            placeholder="أدخل رقم هاتفك"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">البريد الإلكتروني</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition"
            placeholder="أدخل بريدك الإلكتروني"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">النشاط المختار</label>
        <input
          type="text"
          value={activity}
          disabled
          className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">المستوى</label>
        <select
          name="level"
          value={formData.level}
          onChange={handleChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition"
        >
          <option>مبتدئ</option>
          <option>متوسط</option>
          <option>متقدم</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">ملاحظات إضافية</label>
        <textarea
          name="notes"
          value={formData.notes}
          onChange={handleChange}
          rows={3}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition resize-none"
          placeholder="هل لديك أي طلبات خاصة أو إصابات؟"
        />
      </div>

      <div className="flex gap-3 pt-4">
        <Button
          type="submit"
          disabled={isSubmitting}
          className="flex-1 bg-gradient-to-r from-[#003087] to-[#00205b] hover:from-[#e30613] hover:to-[#b80410] text-white font-semibold py-2 rounded-lg transition-all duration-300"
        >
          {isSubmitting ? 'جاري الإرسال...' : 'إرسال طلب التسجيل'}
        </Button>
        <Button
          type="button"
          onClick={onClose}
          variant="outline"
          className="flex-1"
        >
          إلغاء
        </Button>
      </div>
    </form>
  );
}
