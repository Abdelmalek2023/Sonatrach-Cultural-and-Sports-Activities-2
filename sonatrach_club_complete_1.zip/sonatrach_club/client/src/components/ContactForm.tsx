import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Send } from 'lucide-react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    title: '',
    email: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // التحقق من البيانات
    if (!formData.name.trim()) {
      toast.error('الرجاء إدخال الاسم');
      return;
    }

    if (!formData.title.trim()) {
      toast.error('الرجاء إدخال اللقب');
      return;
    }

    if (!formData.email.includes('@')) {
      toast.error('الرجاء إدخال بريد إلكتروني صحيح');
      return;
    }

    if (!formData.message.trim()) {
      toast.error('الرجاء إدخال رسالتك');
      return;
    }

    setIsSubmitting(true);

    // محاكاة إرسال البيانات
    setTimeout(() => {
      toast.success('تم إرسال رسالتك بنجاح! شكراً لتواصلك معنا.');
      setFormData({
        name: '',
        title: '',
        email: '',
        message: '',
      });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-2xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">الاسم</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition"
            placeholder="أدخل اسمك"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">اللقب</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition"
            placeholder="أدخل لقبك"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">البريد الإلكتروني</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition"
            placeholder="أدخل بريدك"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">الرسالة</label>
        <textarea
          name="message"
          value={formData.message}
          onChange={handleChange}
          rows={5}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003087] focus:border-transparent outline-none transition resize-none"
          placeholder="اكتب رسالتك هنا..."
          required
        />
      </div>

      <div className="text-center pt-4">
        <Button
          type="submit"
          disabled={isSubmitting}
          className="bg-gradient-to-r from-[#003087] to-[#00205b] hover:from-[#e30613] hover:to-[#b80410] text-white font-semibold py-3 px-8 rounded-lg transition-all duration-300 inline-flex items-center gap-2"
        >
          <Send size={20} />
          {isSubmitting ? 'جاري الإرسال...' : 'إرسال الرسالة'}
        </Button>
      </div>
    </form>
  );
}
