import { Facebook, Instagram, Youtube, Twitter, MapPin, Phone, Mail, Clock } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'فيسبوك' },
    { icon: Instagram, href: '#', label: 'إنستجرام' },
    { icon: Youtube, href: '#', label: 'يوتيوب' },
    { icon: Twitter, href: '#', label: 'تويتر' },
  ];

  const quickLinks = [
    { label: 'الرئيسية', href: '#home' },
    { label: 'الأنشطة', href: '#activities' },
    { label: 'الأخبار', href: '#news' },
    { label: 'المعرض', href: '#gallery' },
  ];

  const contactInfo = [
    { icon: MapPin, text: 'الجزائر العاصمة - حيدرة' },
    { icon: Phone, text: '+213 21 00 00 00' },
    { icon: Mail, text: 'contact@sonatrach-club.dz' },
    { icon: Clock, text: 'من الأحد إلى الخميس: 8:00 - 18:00' },
  ];

  return (
    <footer className="bg-gray-900 text-gray-300 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* عن النادي */}
          <div className="text-center md:text-right">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/e/ef/Sonatrach.svg"
              alt="سونطراك"
              className="h-20 w-auto mb-4 mx-auto md:mx-0 opacity-80"
            />
            <p className="text-sm leading-relaxed">نادي سونطراك الرياضي والثقافي</p>
            <p className="text-xs text-gray-500 mt-2">مركز رياضي وثقافي متكامل يهدف إلى تنمية المواهب</p>
            
            {/* الروابط الاجتماعية */}
            <div className="flex justify-center md:justify-start gap-3 mt-6">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gray-800 hover:bg-[#e30613] transition-colors duration-300"
                  >
                    <Icon size={18} />
                  </a>
                );
              })}
            </div>
          </div>

          {/* الروابط السريعة */}
          <div className="text-center">
            <h3 className="text-white font-bold text-lg mb-6">روابط سريعة</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm hover:text-[#e30613] transition-colors duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* معلومات التواصل */}
          <div className="text-center md:text-left">
            <h3 className="text-white font-bold text-lg mb-6">معلومات التواصل</h3>
            <div className="space-y-4">
              {contactInfo.map((info, index) => {
                const Icon = info.icon;
                return (
                  <div key={index} className="flex items-start gap-3 justify-center md:justify-start">
                    <Icon size={18} className="text-[#e30613] flex-shrink-0 mt-0.5" />
                    <p className="text-sm">{info.text}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* الفاصل */}
        <div className="border-t border-gray-800 pt-8">
          <p className="text-center text-xs text-gray-500">
            &copy; {currentYear} نادي سونطراك الرياضي والثقافي. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
}
