import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { User, Lock, Briefcase, Eye, EyeOff } from 'lucide-react';

export default function Login() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    employeeId: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // التحقق من البيانات
    if (!formData.username.trim()) {
      toast.error('الرجاء إدخال اسم المستخدم');
      return;
    }

    if (!formData.password.trim()) {
      toast.error('الرجاء إدخال كلمة المرور');
      return;
    }

    if (!formData.employeeId.trim()) {
      toast.error('الرجاء إدخال رقم ID الموظف');
      return;
    }

    if (formData.employeeId.length < 3) {
      toast.error('رقم ID الموظف يجب أن يكون 3 أرقام على الأقل');
      return;
    }

    setIsLoading(true);

    // محاكاة عملية تسجيل الدخول
    setTimeout(() => {
      // يمكن إضافة تحقق من بيانات المستخدم هنا
      // في تطبيق حقيقي، ستتصل بخادم للتحقق
      
      // حفظ بيانات المستخدم في localStorage
      localStorage.setItem('user', JSON.stringify({
        username: formData.username,
        employeeId: formData.employeeId,
        loginTime: new Date().toISOString(),
      }));

      toast.success(`مرحباً ${formData.username}! تم تسجيل الدخول بنجاح`);
      setIsLoading(false);

      // إعادة التوجيه للصفحة الرئيسية
      setLocation('/');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#003087] via-[#00205b] to-[#003087] flex items-center justify-center p-4 relative overflow-hidden">
      {/* خلفية ديكوراتيفية */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#e30613] rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#e30613] rounded-full blur-3xl"></div>
      </div>

      {/* نموذج تسجيل الدخول */}
      <div className="w-full max-w-md relative z-10">
        <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-10">
          {/* الشعار */}
          <div className="flex justify-center mb-8">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/e/ef/Sonatrach.svg"
              alt="شعار سونطراك"
              className="h-24 w-auto"
            />
          </div>

          {/* العنوان */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[#003087] mb-2">نادي سونطراك</h1>
            <p className="text-gray-600 text-sm">الرياضي والثقافي</p>
            <div className="w-16 h-1 bg-gradient-to-r from-[#003087] to-[#e30613] mx-auto mt-4 rounded-full"></div>
          </div>

          {/* نص الترحيب */}
          <p className="text-center text-gray-600 mb-8 text-sm">
            تسجيل الدخول لموظفي النادي
          </p>

          {/* النموذج */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* حقل اسم المستخدم */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                اسم المستخدم
              </label>
              <div className="relative">
                <User className="absolute right-4 top-1/2 -translate-y-1/2 text-[#003087] opacity-60" size={20} />
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleChange}
                  placeholder="أدخل اسم المستخدم"
                  className="w-full pl-4 pr-12 py-3 border-2 border-gray-200 rounded-lg focus:border-[#003087] focus:ring-2 focus:ring-[#003087]/20 outline-none transition-all duration-300"
                  disabled={isLoading}
                />
              </div>
            </div>

            {/* حقل رقم ID الموظف */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                رقم ID الموظف
              </label>
              <div className="relative">
                <Briefcase className="absolute right-4 top-1/2 -translate-y-1/2 text-[#003087] opacity-60" size={20} />
                <input
                  type="text"
                  name="employeeId"
                  value={formData.employeeId}
                  onChange={handleChange}
                  placeholder="أدخل رقم الموظف"
                  className="w-full pl-4 pr-12 py-3 border-2 border-gray-200 rounded-lg focus:border-[#003087] focus:ring-2 focus:ring-[#003087]/20 outline-none transition-all duration-300"
                  disabled={isLoading}
                />
              </div>
            </div>

            {/* حقل كلمة المرور */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                كلمة المرور
              </label>
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-[#003087] opacity-60" size={20} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="أدخل كلمة المرور"
                  className="w-full pl-12 pr-12 py-3 border-2 border-gray-200 rounded-lg focus:border-[#003087] focus:ring-2 focus:ring-[#003087]/20 outline-none transition-all duration-300"
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-[#003087] opacity-60 hover:opacity-100 transition-opacity"
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            {/* خيار تذكر كلمة المرور */}
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  className="w-4 h-4 rounded border-gray-300 text-[#003087] focus:ring-[#003087]"
                  disabled={isLoading}
                />
                <span className="text-gray-600">تذكر كلمة المرور</span>
              </label>
              <a href="#" className="text-[#003087] hover:text-[#e30613] transition-colors font-medium">
                هل نسيت كلمة المرور؟
              </a>
            </div>

            {/* زر تسجيل الدخول */}
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-[#003087] to-[#00205b] hover:from-[#e30613] hover:to-[#b80410] text-white font-bold py-3 rounded-lg transition-all duration-300 mt-6"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  جاري التحقق...
                </span>
              ) : (
                'تسجيل الدخول'
              )}
            </Button>
          </form>

          {/* معلومات إضافية */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-center text-xs text-gray-500">
              هذا النظام مخصص لموظفي نادي سونطراك فقط
            </p>
            <p className="text-center text-xs text-gray-500 mt-2">
              للدعم الفني، يرجى التواصل مع قسم تكنولوجيا المعلومات
            </p>
          </div>
        </div>

        {/* معلومات الاتصال السريعة */}
        <div className="mt-6 text-center text-white text-sm opacity-80">
          <p>📞 +213 21 00 00 00</p>
          <p>📧 support@sonatrach-club.dz</p>
        </div>
      </div>
    </div>
  );
}
