import { useState } from 'react';
import {
  Trophy,
  Dumbbell,
  Waves,
  Zap,
  Palette,
  Music,
  Theater,
  Crown,
} from 'lucide-react';
import Navbar from '@/components/Navbar';
import ActivityCard from '@/components/ActivityCard';
import NewsCard from '@/components/NewsCard';
import GalleryItem from '@/components/GalleryItem';
import RegistrationDialog from '@/components/RegistrationDialog';
import ContactForm from '@/components/ContactForm';
import Footer from '@/components/Footer';

export default function Home() {
  const [registrationOpen, setRegistrationOpen] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState('');

  const handleRegister = (activity: string) => {
    setSelectedActivity(activity);
    setRegistrationOpen(true);
  };

  const activities = [
    {
      icon: Trophy,
      title: 'كرة القدم',
      description: 'تدريبات يومية مع مدربين محترفين',
    },
    {
      icon: Dumbbell,
      title: 'كرة السلة',
      description: 'دوري داخلي وبطولات محلية',
    },
    {
      icon: Waves,
      title: 'السباحة',
      description: 'مسبح أولمبي ودروس لجميع المستويات',
    },
    {
      icon: Zap,
      title: 'التنس',
      description: 'ملاعب مجهزة ومدربون معتمدون',
    },
    {
      icon: Palette,
      title: 'الفنون التشكيلية',
      description: 'ورش رسم ونحت وتصميم',
    },
    {
      icon: Music,
      title: 'الموسيقى',
      description: 'دروس عزف على آلات متنوعة',
    },
    {
      icon: Theater,
      title: 'المسرح',
      description: 'تدريب تمثيل وعروض مسرحية',
    },
    {
      icon: Crown,
      title: 'الشطرنج',
      description: 'نادي شطرنج وبطولات دورية',
    },
  ];

  const news = [
    {
      image: 'https://via.placeholder.com/400x250/e30613/ffffff?text=بطولة+كرة+القدم',
      category: 'رياضة',
      categoryColor: 'bg-blue-600',
      title: 'فريقنا يفوز ببطولة المنطقة',
      date: 'منذ 3 أيام',
      description: 'حقق فريق كرة القدم إنجازًا تاريخيًا بالفوز ببطولة المنطقة بعد منافسة قوية استمرت لمدة شهر.',
    },
    {
      image: 'https://via.placeholder.com/400x250/003087/ffffff?text=معرض+فني',
      category: 'ثقافة',
      categoryColor: 'bg-green-600',
      title: 'افتتاح معرض الفنون التشكيلية',
      date: 'منذ 5 أيام',
      description: 'تم افتتاح معرض أعمال أعضاء قسم الفنون التشكيلية بحضور رسمي وإقبال كبير من الجمهور.',
    },
    {
      image: 'https://via.placeholder.com/400x250/28a745/ffffff?text=برنامج+تدريبي',
      category: 'برامج',
      categoryColor: 'bg-yellow-600',
      title: 'برنامج تدريبي صيفي للأطفال',
      date: 'منذ أسبوع',
      description: 'إطلاق برنامج تدريبي صيفي يشمل رياضات متنوعة وأنشطة ترفيهية للأطفال من 6 إلى 14 سنة.',
    },
  ];

  const gallery = [
    { src: 'https://via.placeholder.com/400x300/003087/ffffff?text=تدريب+كرة+قدم', alt: 'تدريب كرة قدم', isVideo: false },
    { src: 'https://www.w3schools.com/html/mov_bbb.mp4', alt: 'فيديو', isVideo: true },
    { src: 'https://via.placeholder.com/400x300/ffc107/000000?text=معرض+فني', alt: 'معرض فني', isVideo: false },
    { src: 'https://via.placeholder.com/400x300/198754/ffffff?text=سباحة', alt: 'سباحة', isVideo: false },
    { src: 'https://www.w3schools.com/html/mov_bbb.mp4', alt: 'مسرح', isVideo: true },
    { src: 'https://via.placeholder.com/400x300/dc3545/ffffff?text=شطرنج', alt: 'شطرنج', isVideo: false },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section
        id="home"
        className="pt-20 pb-20 bg-gradient-to-b from-[#003087] to-[#00205b] text-white relative overflow-hidden"
      >
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#e30613] rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#e30613] rounded-full blur-3xl"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center py-20">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              نادي سونطراك الرياضي والثقافي
            </h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 max-w-3xl mx-auto">
              مركز رياضي وثقافي متكامل يهدف إلى تنمية المواهب وتعزيز الروح الجماعية
            </p>
            <button
              onClick={() => {
                const element = document.getElementById('activities');
                element?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-white text-[#003087] font-bold py-3 px-8 rounded-lg hover:bg-[#e30613] hover:text-white transition-all duration-300 text-lg"
            >
              اكتشف أنشطتنا
            </button>
          </div>
        </div>
      </section>

      {/* Activities Section */}
      <section id="activities" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#003087] mb-4">أنشطتنا الرياضية والثقافية</h2>
            <p className="text-gray-600 text-lg">مجموعة متنوعة من الأنشطة تناسب جميع الأعمار والاهتمامات</p>
            <div className="w-20 h-1 bg-gradient-to-r from-[#003087] to-[#e30613] mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {activities.map((activity) => (
              <ActivityCard
                key={activity.title}
                icon={activity.icon}
                title={activity.title}
                description={activity.description}
                onRegister={() => handleRegister(activity.title)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* News Section */}
      <section id="news" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#003087] mb-4">آخر الأخبار والبرامج</h2>
            <p className="text-gray-600 text-lg">تابع أحدث الفعاليات والإنجازات</p>
            <div className="w-20 h-1 bg-gradient-to-r from-[#003087] to-[#e30613] mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {news.map((item) => (
              <NewsCard
                key={item.title}
                image={item.image}
                category={item.category}
                categoryColor={item.categoryColor}
                title={item.title}
                date={item.date}
                description={item.description}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#003087] mb-4">معرض الصور والفيديوهات</h2>
            <p className="text-gray-600 text-lg">لقطات من أنشطتنا وفعالياتنا</p>
            <div className="w-20 h-1 bg-gradient-to-r from-[#003087] to-[#e30613] mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {gallery.map((item, index) => (
              <GalleryItem
                key={index}
                src={item.src}
                alt={item.alt}
                isVideo={item.isVideo}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Registration Section */}
      <section id="register" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#003087] mb-4">سجل الآن</h2>
            <p className="text-gray-600 text-lg">انضم إلى أحد أنشطتنا واستمتع بتجربة فريدة</p>
            <div className="w-20 h-1 bg-gradient-to-r from-[#003087] to-[#e30613] mx-auto mt-6 rounded-full"></div>
          </div>

          <div className="max-w-2xl mx-auto bg-gradient-to-br from-[#003087]/5 to-[#e30613]/5 rounded-2xl p-12 text-center">
            <p className="text-gray-700 text-lg mb-6">
              اختر النشاط الذي تهتم به من الأعلى واضغط على زر "تسجيل الآن" لملء نموذج التسجيل
            </p>
            <p className="text-gray-600">
              سيتم التواصل معك قريباً لتأكيد تسجيلك والبدء في النشاط المختار
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[#003087] mb-4">تواصلوا معنا</h2>
            <p className="text-gray-600 text-lg">نرحب باستفساراتكم وملاحظاتكم</p>
            <div className="w-20 h-1 bg-gradient-to-r from-[#003087] to-[#e30613] mx-auto mt-6 rounded-full"></div>
          </div>

          <ContactForm />
        </div>
      </section>

      {/* Footer */}
      <Footer />

      {/* Registration Dialog */}
      <RegistrationDialog
        open={registrationOpen}
        activity={selectedActivity}
        onOpenChange={setRegistrationOpen}
      />
    </div>
  );
}
